import javax.swing.*;
/* javax.swing.* - Provides interfaces that enable the development of input methods that can be used with any Java runtime environment. */

public class App {
    
    public static void main(String[] args) throws Exception {
        int boardWidth = 360;
        int boardHeight = 640; 

        JFrame frame = new JFrame("Flappy Bird");
        /* Provides a window on the screen */

        //frame.setVisible(true);
        /* Allows user to see window */

        frame.setSize(boardWidth, boardHeight);
        /* sets size of the frame eqivualent to what the parameters are */

        frame.setLocationRelativeTo(null);
        /* Sets the location of this point to the specificed float coordinates */

        frame.setResizable(false); 
        /* Sets Size to adjust size*/

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        FlappyBird flappyBird = new FlappyBird();
        frame.add(flappyBird);
        frame.pack();
        flappyBird.requestFocus();  
        frame.setVisible(true);

    }

/* throws Exception - to explicitly throw an exception from a method or any block of code. */

}